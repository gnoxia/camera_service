

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/flash/smart/lib/

