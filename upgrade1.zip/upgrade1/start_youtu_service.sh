if [ -d /mnt/flash/smart/youtu_service/app ]
then
ln -s /mnt/flash/smart/youtu_service/app/lib /tmp/lib/youtu
ln -s /mnt/flash/smart/youtu_service/app/config/model /tmp/vcaconfig/youtu/model
else
ln -s /mnt/flash/smart/youtu_service/current/lib /tmp/lib/youtu
ln -s /mnt/flash/smart/youtu_service/current/config/model /tmp/vcaconfig/youtu/model
fi

export LD_LIBRARY_PATH=/tmp/lib/youtu/:$LD_LIBRARY_PATH
ln -s /mnt/flash/smartinfo/cert/youtu.license /tmp/vcaconfig/youtu/youtu.license
export YT_ROOT_PATH=/mnt/flash/smart/youtu_service
export LOG_URL="http://192.168.1.106:1234"
export LOG_LEVEL=4

/mnt/flash/smart/youtu_service/yt_daemon&
